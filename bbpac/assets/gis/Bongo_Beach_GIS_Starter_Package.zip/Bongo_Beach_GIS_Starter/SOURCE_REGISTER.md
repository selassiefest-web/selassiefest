# Source Register

| Layer | Custodian | Published description / vintage | Role | Limitation |
|---|---|---|---|---|
| Jackson Park #19 | Chicago Park District via City of Chicago Data Portal | Current CPD property boundaries as of 2016-11-04 | Official administrative baseline | Not represented as a survey; needs CPD confirmation of post-2016 changes |
| 63rd Street shorelines | Illinois State Geological Survey / IDNR Coastal Management Program | Wet/dry lines digitized at 1:250 from UAS orthomosaics; 2021, 2022, 2023, 2024 | Coastal-change evidence | Dynamic physical line; not a fixed park boundary |
| Operational footprint | To be assembled | Pending | Separates beach operations from Park #19 title/administrative polygon | Must be supported by asset, staffing, safety, maintenance, and program evidence |
| Proposed Bongo Beach | Proponent-authored | Pending | Requested new administrative unit | Must use stable, explainable controls and remain explicitly proposed |
