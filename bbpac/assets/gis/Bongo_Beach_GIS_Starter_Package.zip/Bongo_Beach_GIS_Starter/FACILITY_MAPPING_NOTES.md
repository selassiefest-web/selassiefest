# 63rd Street Beach Facility Mapping Notes

## Mapped with strong documentary support

- Historic Beach House / Pavilion, including the CPD-described lifeguard office association.
- Pay-and-display parking lot.
- Non-motorized boat launch.
- ADA beach walk and paved path system (working centerlines require field verification).
- Approximately 12-acre dune habitat split into northern and southern sections.
- Pedestrian underpass connections.
- 64th Street distance-swimming geography, documented as parallel to shore between the first and third buoys.
- Life-ring coverage identified by CPD as ring number 025 for the 59th-to-63rd Street Beach segment.

## Precision warning

CPD publishes the existence and operational description of the swimming area, lifeguard office, buoys, and life-ring coverage but does not publish survey coordinates for the deployed safety equipment. The exhibit therefore distinguishes mapped candidate buoy points from generalized operational references. Exact cabinet, guard-chair, flag, buoy-number, rescue-board, AED, and emergency-access locations require a CPD asset export or field survey.

## Administrative use

These layers support the eventual transfer matrix. Inclusion inside a proposed Bongo Beach polygon does not itself establish ownership, jurisdiction, or an approved transfer.
