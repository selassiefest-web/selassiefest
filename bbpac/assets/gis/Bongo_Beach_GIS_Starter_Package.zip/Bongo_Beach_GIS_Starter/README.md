# Proposed Bongo Beach GIS — Starter Package

This starter establishes the evidence architecture without inventing the proposed boundary.

## Geometry classes kept separate

1. `jackson_park_19_existing` — official CPD/Data Portal property polygon (published vintage: 2016-11-04).
2. `isgs_63rd_shorelines_2021_2024` — surveyed wet/dry shoreline observations, not an administrative boundary.
3. `beach_operational_footprint` — empty decision layer pending asset and operating-area evidence.
4. `bongo_beach_proposed` — empty decision layer pending selection of stable boundary controls.

## Coordinate systems

- Exchange/publication: WGS 84 longitude/latitude (EPSG:4326).
- Area, perimeter, and drafting: NAD83 / Illinois East (ftUS) (EPSG:3435).
- Original ISGS shoreline files are preserved with their native projection metadata.

## Next evidence needed

- Current CPD asset inventory and building/facility identifiers.
- Authoritative roads/right-of-way polygons (centerlines alone are insufficient for a legal-style carve-out).
- Aerial orthomosaic or survey-grade base for paths, parking, underpass, dunes, boat launch, life rings, and swim-control geography.
- Operational evidence defining what CPD treats as “63rd Street Beach.”
- Policy decision on inclusion/exclusion of the Beach House, boat launch, parking, underpass approaches, and water area.

No empty layer in this package should be mistaken for an absent feature. It means the geometry has not yet been defensibly established.
