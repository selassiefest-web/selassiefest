# Proposed Bongo Beach GIS — Starter Package

This starter establishes the evidence architecture without inventing the proposed boundary.

## Geometry classes kept separate

1. `jackson_park_19_existing` — official CPD/Data Portal property polygon (published vintage: 2016-11-04).
2. `isgs_63rd_shorelines_2021_2024` — surveyed wet/dry shoreline observations, not an administrative boundary.
3. `beach_operational_footprint` — empty decision layer pending asset and operating-area evidence; see `04_exports/beach_operational_*_candidate1.geojson` for the Candidate 1 planning envelope under review (Exhibit B).
4. `bongo_beach_proposed` — empty decision layer pending selection of stable boundary controls; see `04_exports/bongo_beach_proposed_candidate1_draft.geojson` for the Candidate 1 draft boundary under review.

## Beach House interior detail

Reconstructed from CPD's official facility layout (`01_source_data/CPD_63rd_Beach_House_Official_Layout.pdf`) and the CPD Special Event Venue page, cross-referenced against OSM (`01_source_data/OSM_Pavilion_Detail_2026-09-02.json`). See `PAVILION_LAYER_STATUS.md` for what's created vs. still requiring field capture or CPD plans.

- `04_exports/beach_house_subspaces.geojson` — the 8 architectural subspaces (Fountain Courtyard, Town Square/Serenity Courtyard, central pavilion, balconies, terminal pavilions, front-entry spine).
- `04_exports/beach_house_entries.geojson` — 7 entrance/access points.
- `04_exports/concessions.geojson` — Reggies On The Beach.
- `04_exports/building_amenities.geojson` — 5 building-associated amenities (lifeguard office, restrooms, showers, meeting rooms, water-play feature).
- `04_exports/access_controls.geojson` — 6 gates, bollards, and access-control points.

Plan-derived geometry is suitable for administrative planning and field-survey preparation, not construction, leasing, or accessibility certification.

## Coordinate systems

- Exchange/publication: WGS 84 longitude/latitude (EPSG:4326).
- Area, perimeter, and drafting: NAD83 / Illinois East (ftUS) (EPSG:3435).
- Original ISGS shoreline files are preserved with their native projection metadata.

## Next evidence needed

- Current CPD asset inventory and building/facility identifiers.
- Authoritative roads/right-of-way polygons (centerlines alone are insufficient for a legal-style carve-out).
- Aerial orthomosaic or survey-grade base for paths, parking, underpass, dunes, boat launch, life rings, and swim-control geography.
- Operational evidence defining what CPD treats as “63rd Street Beach.”
- Policy decision on inclusion/exclusion of the Beach House, boat launch, parking, underpass approaches, and water area.

No empty layer in this package should be mistaken for an absent feature. It means the geometry has not yet been defensibly established.
